package com.example.android.simplejams;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Everette on 7/12/2017.
 */
public class  IInAppBillingService extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent serviceIntent =
                new Intent("com.android.vending.billing.InAppBillingService.BIND");
        serviceIntent.setPackage("com.android.vending");
        ServiceConnection mServiceConn = null;
        bindService(serviceIntent, mServiceConn, Context.BIND_AUTO_CREATE);
    }

    final IInAppBillingService[] mService = new IInAppBillingService[1];

    ServiceConnection mServiceConn = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService[0] = null;
        }

        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            mService[0] = IInAppBillingService.Stub.asInterface(service);
        }
    };

    public class Stub {
    }
}
