package com.example.android.simplejams;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Set the content of the activity to use in the xml
        setContentView(R.layout.activity_main);


        //Find the view that shows each list
        TextView Rock = (TextView)findViewById(R.id.Rock);
        TextView Pop = (TextView)findViewById(R.id.Pop);
        TextView Country  = (TextView)findViewById(R.id.Country);
        TextView HipHop  = (TextView)findViewById(R.id.HipHop);
        TextView Payment = (TextView)findViewById(R.id.Payment);

        //Set a clicklistener
        Rock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent RockIntent = new Intent(MainActivity.this, Rock.class);
                startActivity(RockIntent);

            }
        });
        Pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent PopIntent = new Intent(MainActivity.this, Pop.class);
                startActivity(PopIntent);

            }
        });
        HipHop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent HipHopIntent = new Intent(MainActivity.this, HipHop.class);
                startActivity(HipHopIntent);

            }
        });
        Country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent CountryIntent = new Intent(MainActivity.this, Country.class);
                startActivity(CountryIntent);

            }
        });
        Payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {Intent PaymentIntent = new Intent(MainActivity.this, Payment.class);
                startActivity(PaymentIntent);

            }
        });
    }

}
