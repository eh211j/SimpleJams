package com.example.android.simplejams;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Pop extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop);
    }

    public class PopClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Toast.makeText(view.getContext(),
                    "Open Pop List", Toast.LENGTH_SHORT).show();
        }
    }
}
